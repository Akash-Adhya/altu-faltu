package model;

public class Product {
	int productId;
	String productName;
	double productPrice;
	int productQuantity;
	String productCategory;
	String productDescrpition;

	public Product(int productId, String productName, double productPrice, int productQuantity, String productCategory,
			String productDescrpition) {
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productQuantity = productQuantity;
		this.productCategory = productCategory;
		this.productDescrpition = productDescrpition;
	}

	public int getProductId() {
		return productId;
	}

	public String getProductName() {
		return productName;
	}

	public double getProductPrice() {
		return productPrice;
	}

	public int getProductQuantity() {
		return productQuantity;
	}

	public String getProductCategry() {
		return productCategory;
	}

	public String getProductDescription() {
		return productDescrpition;
	}
}