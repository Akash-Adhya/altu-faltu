package model;

public class users {
	
	int UserId;
	String UserName;
	String UserEmail;
	String UserPassword;
	
	public users(int UserId, String UserName, String UserEmail, String UserPassword) {
	this.UserId=UserId;
	this.UserName=UserName;
	this.UserEmail=UserEmail;
	this.UserPassword=UserPassword;
	}
	
	public int getUserId() {return UserId;}
	public String getUserName() {return UserName;}
	public String getUserEmail() {return UserEmail;}
	public String getUserPassword() {return UserPassword;}

}

