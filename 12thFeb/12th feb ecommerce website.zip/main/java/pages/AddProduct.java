package pages;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ProductDAO;
import model.Product;

/**
 * Servlet implementation class AddProduct
 */
@WebServlet("/add")
public class AddProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddProduct() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		response.setContentType("text/html");

		String productName = request.getParameter("productName");
		String productDescription = request.getParameter("productDescription");
		int productQuantity = Integer.parseInt(request.getParameter("productQuantity"));
		String productCategory = request.getParameter("productCategory");
		double price = Double.parseDouble(request.getParameter("productPrice"));
		
		Product p = new Product();
		
		p.setProductName(productName);
		p.setProductCategory(productCategory);
		p.setProductPrice(price);
		p.setProductDescription(productDescription);
		p.setProductQuantity(productQuantity);
		
		ProductDAO obj = new ProductDAO();
		boolean stat = obj.insert(p);
		if(stat) {
			response.sendRedirect("AdminDashboard.jsp");
			
		} else {
			PrintWriter out = response.getWriter();
			out.println("<h3>Error Adding product</h3>");
			out.println("<a href='AdminDashboard.jsp'>Back to Admin Dashboard</a>"); 
		}
	}

}
