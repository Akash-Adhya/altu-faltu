package login;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.*;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet Filter implementation class validateFilter
 */
@WebFilter("/validateFilter")
public class validateFilter extends HttpFilter implements Filter {
       
    /**
     * @see HttpFilter#HttpFilter()
     */
    public validateFilter() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		HttpServletRequest req = (HttpServletRequest) request;
		String uname = req.getParameter("email");
		String pass = req.getParameter("pass");
		HttpServletResponse res = (HttpServletResponse) response;
        ServletContext ctx = request.getServletContext();
        Map<String,String> userMap = (Map<String,String>) ctx.getAttribute("userMap");
        
		if(uname != null && pass!=null) {
			if(pass.equals(userMap.get("uname"))) {
				System.out.println("login successful");
				chain.doFilter(request, response);
				return;
				
			}
		}else {
			res.sendRedirect("login.jsp?error=invalid");
		}
		
//		String jdbcurl = "jdbc:mysql://localhost:3306/e_commerce_app";
//		String User = "root";
//		String Pass = "root@39";
//		String drive = "com.mysql.cj.jdbc.Driver";
//		String sql = "Select * from user";
//		try{
//			Connection con = DriverManager.getConnection(jdbcurl,User,Pass);
//			PreparedStatement ps = con.prepareStatement(sql);
//			
//			//for( Map.Entry<Integer,Integer> e : markperstudent.entrySet()){
////				ps.setInt(1, e.getValue());
////				ps.setInt(2, e.getKey());
////				ps.executeUpdate();
//			}catch(Exception e) {}
		
		
		//chain.doFilter(request, response);
		
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}



