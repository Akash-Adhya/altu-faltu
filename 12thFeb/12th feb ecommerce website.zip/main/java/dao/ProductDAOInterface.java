package dao;

import java.util.List;

import model.Product;

public interface ProductDAOInterface {
	
	public boolean insert(Product u);
	public void update(Product u);
	public void delete(Product u);
	
	public Product getByProductId(int id);
	public List<Product> getAllProducts();
	
}
