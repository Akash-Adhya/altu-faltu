package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.User;

public class UserDAO implements UserDAOInterface {

	User user = new User();
	Connection conn = null;
	PreparedStatement pst = null;
	ResultSet rs = null;

	private void getConnection() {

		String url = "jdbc:mysql://localhost:3306/e_commerce_app";
		String username = "root";
		String password = "akash9851";

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(url, username, password);
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	@Override
	public void insert(User u) {

		try {
			getConnection();
			pst = conn.prepareStatement("insert into user values(?, ?, ?, ?, ?);");

			pst.setInt(1, u.getUserId());
			pst.setString(2, u.getUserName());
			pst.setString(3, u.getUserEmail());
			pst.setString(4, u.getUserPassword());
			pst.setString(5, u.getUserType());

			int rows = pst.executeUpdate();

			if (rows > 0) {
				System.out.println("Successfully inserted!");
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void update(User u) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(User u) {
		// TODO Auto-generated method stub

	}

	@Override
	public User getByUserId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<User> getAllUsers() {
		List<User> users = new ArrayList<>();
		try {
			getConnection();
			pst = conn.prepareStatement("select * from user");
			rs = pst.executeQuery();
			while (rs.next()) {
				User u = new User();
				
				u.setUserId(rs.getInt("u_id"));
				u.setUserName(rs.getString("u_name"));
				u.setUserEmail(rs.getString("u_name"));
				u.setUserPassword(rs.getString("u_pass"));
				u.setUserType(rs.getString("u_type"));
				
				users.add(u);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return users;

	}

}
