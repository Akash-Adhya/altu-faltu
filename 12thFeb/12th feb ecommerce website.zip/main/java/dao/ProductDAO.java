package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import model.Product;
import model.User;

public class ProductDAO implements ProductDAOInterface {

	Product p = new Product();
	private Connection conn = null;
	private PreparedStatement pst = null;
	private ResultSet rs = null;

	private void getConnection() {

		String url = "jdbc:mysql://localhost:3306/e_commerce_app";
		String username = "root";
		String password = "akash9851";

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn = DriverManager.getConnection(url, username, password);
			
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	@Override
	public boolean insert(Product p) {
		
		try {
			getConnection();
			
			pst = conn.prepareStatement("INSERT INTO product VALUES(?, ?, ?, ?, ?);");
			pst.setString(1, p.getProductName());
			pst.setString(2, p.getProductCategory());
			pst.setString(3, p.getProductDescription());
			pst.setInt(4, p.getProductQuantity());
			pst.setDouble(5, p.getProductPrice());
			
			pst.executeUpdate();
			
			return true;
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		}

	}

	@Override
	public void update(Product u) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(Product u) {
		// TODO Auto-generated method stub

	}

	@Override
	public Product getByProductId(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> getAllProducts() {

		List<Product> products = new ArrayList<>();
		try {
			getConnection();
			pst = conn.prepareStatement("select * from product");
			rs = pst.executeQuery();
			while (rs.next()) {
				Product p = new Product();

				p.setProductId(rs.getInt("p_id"));
				p.setProductName(rs.getString("p_name"));
				p.setProductCategory(rs.getString("category"));
				p.setProductDescription(rs.getString("description"));
				p.setProductQuantity(rs.getInt("quantity"));
				p.setProductPrice(rs.getDouble("price"));

				products.add(p);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return products;
	}

}
